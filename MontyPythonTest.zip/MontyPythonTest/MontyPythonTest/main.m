//
//  main.m
//  MontyPythonTest
//
//  Created by Conor Sweeney on 12/11/15.
//  Copyright © 2015 Conor Sweeney. All rights reserved.
//

#import <Foundation/Foundation.h>



void montyAlgo (int numberOfTries){

    for (int x = 0; x < numberOfTries ; x++) {
        NSMutableDictionary *valueDictionary = [[NSMutableDictionary alloc]init];
        [valueDictionary setValue:@"Goat" forKey:@"1"];
        [valueDictionary setValue:@"Goat" forKey:@"2"];
        [valueDictionary setValue:@"Car" forKey:@"3"];
        
        NSMutableArray *arryRandomNumber=[[NSMutableArray alloc]init];
        while (arryRandomNumber.count<3) {
            NSInteger randomNumber =1+arc4random()%3;
            if (![arryRandomNumber containsObject:[NSString stringWithFormat:@"%ld",(long)randomNumber]])
            {
                [arryRandomNumber addObject:[NSString stringWithFormat:@"%ld",(long)randomNumber]];
            }
            continue;
        }
        //NSLog(@"%@",arryRandomNumber);
        
        NSString *door1Key = [arryRandomNumber objectAtIndex:0];
        NSString *door2Key = [arryRandomNumber objectAtIndex:1];
        NSString *door3Key = [arryRandomNumber objectAtIndex:2];
        
        NSString *door1Value = [valueDictionary objectForKey:door1Key];
        NSString *door2Value = [valueDictionary objectForKey:door2Key];
        NSString *door3Value = [valueDictionary objectForKey:door3Key];
        
        NSLog(@"\nDoor 1 Prize - %@\nDoor 2 Prize -%@\nDoor 3 Prize - %@\n",door1Value,door2Value,door3Value);
    }
    
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        montyAlgo(5);
    }
    return 0;
}

